# 🎫 Helpdesk EMSLC - Sistema de Suporte de TI

<div align="center">

![React](https://img.shields.io/badge/React-19.2.0-61DAFB?style=for-the-badge&logo=react&logoColor=white)
![Vite](https://img.shields.io/badge/Vite-7.2.4-646CFF?style=for-the-badge&logo=vite&logoColor=white)
![Firebase](https://img.shields.io/badge/Firebase-12.8.0-FFCA28?style=for-the-badge&logo=firebase&logoColor=black)
![Styled Components](https://img.shields.io/badge/Styled_Components-6.3.8-DB7093?style=for-the-badge&logo=styled-components&logoColor=white)

**Sistema de abertura e gerenciamento de chamados de suporte técnico para escolas**

[🌐 Acessar Sistema](https://emslchelp.vercel.app) · [📋 Funcionalidades](#-funcionalidades) · [🚀 Instalação](#-instalação)

</div>

---

## 📖 Sobre o Projeto

O **Helpdesk EMSLC** é uma aplicação web moderna desenvolvida para facilitar a comunicação entre os funcionários de uma escola e a equipe de suporte de TI. O sistema permite a abertura de chamados técnicos de forma simples e intuitiva, com acompanhamento em tempo real do status de cada solicitação.

### 🎯 Objetivo

Centralizar e organizar todas as solicitações de suporte técnico da escola, proporcionando:

- Maior agilidade no atendimento
- Rastreabilidade completa dos chamados
- Comunicação eficiente entre usuários e técnicos
- Relatórios e métricas de desempenho

---

## ✨ Funcionalidades

### 👤 Para Usuários

- **Abertura de Chamados** - Crie solicitações de suporte com descrição detalhada
- **Categorização** - Escolha entre: Computador, Projetor, Programa, Rede/Internet ou Outros
- **Acompanhamento** - Visualize o status do seu chamado em tempo real
- **Busca por Código** - Encontre chamados usando o código OS N°XXXXX
- **Notificações** - Receba atualizações sobre mudanças no status
- **Histórico** - Acesse todos os seus chamados anteriores
- **Download PDF** - Baixe comprovantes dos chamados abertos

### 👨‍💼 Para Administradores

- **Dashboard Completo** - Visualize todos os chamados em uma interface organizada
- **Filtros Avançados** - Filtre por: Todos, Pendentes, Encaminhados, Concluídos
- **Gestão de Status** - Atualize o progresso dos chamados
- **Encaminhamento** - Encaminhe chamados para a Prodabel quando necessário
- **Sistema de Notificações** - Alertas para novos chamados
- **Relatórios Visuais** - Gráficos e estatísticas com Recharts

### 🎨 Recursos Gerais

- **Tema Claro/Escuro** - Alterne entre modos de visualização
- **Design Responsivo** - Funciona em desktop, tablet e celular
- **PWA** - Instale como aplicativo no seu dispositivo
- **Animações Suaves** - Experiência moderna com Framer Motion
- **Tempo Real** - Atualizações instantâneas via Firebase

---

## 🛠️ Tecnologias Utilizadas

### Frontend

| Tecnologia        | Versão  | Descrição                                |
| ----------------- | ------- | ---------------------------------------- |
| React             | 19.2.0  | Biblioteca para construção de interfaces |
| Vite              | 7.2.4   | Build tool e dev server ultrarrápido     |
| React Router DOM  | 7.12.0  | Roteamento de páginas SPA                |
| Styled Components | 6.3.8   | CSS-in-JS para estilização               |
| Framer Motion     | 12.27.1 | Biblioteca de animações                  |
| React Icons       | 5.5.0   | Ícones para React                        |
| React Toastify    | 11.0.5  | Notificações toast                       |
| Recharts          | 3.6.0   | Gráficos e visualizações                 |
| jsPDF             | 4.0.0   | Geração de arquivos PDF                  |

### Backend & Infraestrutura

| Tecnologia         | Descrição                    |
| ------------------ | ---------------------------- |
| Firebase Auth      | Autenticação de usuários     |
| Firebase Firestore | Banco de dados em tempo real |
| Cloudinary         | Armazenamento de imagens     |
| Vercel             | Hospedagem e deploy          |

---

## 📁 Estrutura do Projeto

```
src/
├── app/
│   ├── layouts/           # Layouts base (Admin, App, Público)
│   ├── paginas/
│   │   ├── admin/         # Páginas administrativas
│   │   ├── auth/          # Autenticação (Login, Cadastro, etc)
│   │   └── usuario/       # Páginas do usuário
│   └── rotas/             # Configuração de rotas
├── assets/                # Imagens e arquivos estáticos
├── componentes/
│   ├── admin/             # Componentes do painel admin
│   ├── chamados/          # Componentes de chamados
│   └── ui/                # Componentes reutilizáveis
├── contextos/             # Context API (Auth, Tema, etc)
├── estilos/               # Estilos globais e temas
├── hooks/                 # Custom hooks
├── servicos/
│   └── firebase/          # Serviços Firebase
└── utils/                 # Funções utilitárias
```

---

## 🚀 Instalação

### Pré-requisitos

- Node.js 18+ instalado
- NPM ou Yarn
- Conta no Firebase (para backend)

### Passo a Passo

1. **Clone o repositório**

```bash
git clone https://github.com/seu-usuario/helpdesk-escola.git
cd helpdesk-escola
```

2. **Instale as dependências**

```bash
npm install
```

3. **Configure as variáveis de ambiente**

Crie um arquivo `.env` na raiz do projeto:

```env
VITE_FIREBASE_API_KEY=sua_api_key
VITE_FIREBASE_AUTH_DOMAIN=seu_projeto.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=seu_projeto
VITE_FIREBASE_STORAGE_BUCKET=seu_projeto.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=seu_sender_id
VITE_FIREBASE_APP_ID=seu_app_id
VITE_CLOUDINARY_CLOUD_NAME=seu_cloud_name
```

4. **Inicie o servidor de desenvolvimento**

```bash
npm run dev
```

5. **Acesse no navegador**

```
http://localhost:5173
```

---

## 📜 Scripts Disponíveis

| Comando           | Descrição                              |
| ----------------- | -------------------------------------- |
| `npm run dev`     | Inicia o servidor de desenvolvimento   |
| `npm run build`   | Gera a versão de produção              |
| `npm run preview` | Visualiza o build de produção          |
| `npm run lint`    | Executa o ESLint para verificar código |

---

## 🔒 Regras de Segurança

O Firestore está configurado com regras de segurança que:

- Permitem leitura de chamados apenas para administradores e donos
- Restringem escrita baseada em autenticação
- Protegem dados sensíveis dos usuários

---

## 📱 PWA (Progressive Web App)

O sistema pode ser instalado como um aplicativo:

1. Acesse o site em um navegador compatível
2. Clique em "Instalar" ou "Adicionar à tela inicial"
3. Use como um app nativo no seu dispositivo

---

## 🎨 Temas

O sistema oferece dois temas:

| Tema      | Cor Principal | Fundo        |
| --------- | ------------- | ------------ |
| 🌙 Escuro | #0a0b0e       | Tons escuros |
| ☀️ Claro  | #f5f6f8       | Tons claros  |

A preferência do usuário é salva localmente.

---

## 📊 Fluxo de um Chamado

```
1. Usuário abre chamado
         ↓
2. Status: PENDENTE 🟡
         ↓
3. Admin visualiza e analisa
         ↓
    ┌────┴────┐
    ↓         ↓
PRODABEL   CONCLUÍDO
  🔵         🟢
```

---

## 🤝 Contribuição

Contribuições são bem-vindas! Para contribuir:

1. Faça um Fork do projeto
2. Crie uma branch para sua feature (`git checkout -b feature/NovaFeature`)
3. Commit suas mudanças (`git commit -m 'Adiciona NovaFeature'`)
4. Push para a branch (`git push origin feature/NovaFeature`)
5. Abra um Pull Request

---

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

---

## 👨‍💻 Autor

Desenvolvido com ❤️ para facilitar o suporte técnico nas escolas.

---

<div align="center">

**[⬆ Voltar ao topo](#-helpdesk-emslc---sistema-de-suporte-de-ti)**

</div>
