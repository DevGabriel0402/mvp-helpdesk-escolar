import { usarNotificacoes } from "../contextos/NotificacoesContexto";

export function useNotificacoesChamados() {
    return usarNotificacoes();
}
